# TIR-REF — Offline Desktop Reference (Illustrative)

This is an offline-first desktop reference implementation demonstrating:
- intake → classification → rule selection → sequencing → filings → TIR record
- local case save/load
- offline KB search

Run:
```bat
python app\tir_desktop.py
```
