Reference implementation is illustrative only and not production-ready. Not legal/tax advice.
