# TIR-STD (Specification)

This directory defines the **Transaction Intelligence Registry Standard**:
- canonical schemas
- rule-pack format
- sequencing model
- versioning rules

All files in `spec/` are normative unless explicitly labeled “informative”.
