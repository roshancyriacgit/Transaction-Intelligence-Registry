Place generated sample outputs here (no real data). Example outputs should be illustrative only.
