# Comparison (Informative)

- India Stack rails: execute identity/payments/consent/documents/data
- TIR: standardises pre-execution intent → considerations → sequencing
- Traditional checklists: local and non-interoperable
- TIR: interoperable and versioned, with traceability
