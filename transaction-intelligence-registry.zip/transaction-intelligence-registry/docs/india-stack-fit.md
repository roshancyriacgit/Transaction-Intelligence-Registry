# India Stack Fit

India Stack provides rails for:
- identity, consent, payments, documents, and data

TIR sits upstream as a pre-execution intelligence layer:
- clarifies transaction intent
- surfaces applicable obligations and sequencing
- improves correctness before execution on rails
