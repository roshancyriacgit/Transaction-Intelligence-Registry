# Code of Conduct

This project follows the Contributor Covenant Code of Conduct (v2.1) in spirit.

- Be respectful and constructive.
- Focus discussion on improving the standard and reference implementation.
- Harassment and abusive conduct are not tolerated.

Project maintainers may remove content or contributions that violate these norms.
